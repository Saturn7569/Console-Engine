namespace ConsoleEngine {
    public class RenderGrid {
        public int WIDTH;
        public int HEIGHT;

        private List<char[]> screen = new List<char[]>();
        private List<string> UI = new List<string>();

        public RenderGrid(int w,int h,char emptyTile) {
            WIDTH = w;
            HEIGHT = h;

            for (int a=0;a<HEIGHT;a++) {
                char[] row = new char[WIDTH];
                for (int j=0;j<WIDTH;j++) {
                    row[j] = emptyTile;
                }
                screen.Add(row);
            }

            UI.Add(GetEmptyString());
            UI.Clear();
        }

        public void InitWindow(string title) {
            Console.Title = title;
        }

        public void Render() {
            foreach (string element in UI) {
                if (element != GetEmptyString()) {
                    Console.WriteLine(element);
                }
            }
            for (int a=0;a<HEIGHT;a++) {
                for (int b=0;b<WIDTH;b++) {
                    Console.Write(screen[a][b]);
                }
                Console.WriteLine();
            }
        }

        public void DrawChar(char ent,int x,int y) {
            if (x < WIDTH && y < HEIGHT) {
                screen[y][x] = ent;
            }
            else {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("ERROR: Invalid coordionate");
                Console.ForegroundColor = ConsoleColor.White;
            }
        }

        public void Clear(char emptyTile) {
            Console.Clear();
            UI.Clear();
            for (int a=0;a<HEIGHT;a++) {
                for (int b=0;b<WIDTH;b++) {
                    screen[a][b] = emptyTile;
                }
            }
        }
        
        public ConsoleKey CheckKeyPressed() {
            return Console.ReadKey().Key;
        }

        public void DrawUI(string text) {
            UI.Add(text);
        }

        // Private calls
        private string GetEmptyString() {
            return "";
        }
    }

    class Vector2 {
        public int x, y;

        public Vector2(int startX, int startY) {
            x = startX;
            y = startY;
        }

        public bool Compare(Vector2 pos2) {
            return x == pos2.x && y == pos2.y;
        }

        public void Set(int _x, int _y) {
            x = _x;
            y = _y;
        }
    }

    namespace EntityManagement {
        class Entity {
            public Vector2 position = new(0,0);
            public char texture;

            public Entity(int startX, int startY, char _texture) {
                position.x = startX;
                position.y = startY;
                texture = _texture;
            }

            public void Draw(RenderGrid screen) {
                screen.DrawChar(texture,position.x,position.y);
            }

            public bool CheckCollision(Entity collisionEntity) {
                return position.Compare(collisionEntity.position);
            }
        }
    }
}